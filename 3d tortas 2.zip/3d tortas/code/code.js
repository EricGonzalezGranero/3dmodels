gsap.registerPlugin(ScrollTrigger) 

gsap.to('#textoinicio', {
    scrollTrigger:  {
        trigger:"#inicio",
        
        start: "bottom bottom",
        end:"+=1500",
        scrub:true,
       
    },
    opacity: 0,
});

gsap.to('#columna1', {
    scrollTrigger:  {
        trigger:"#inicio",
        
        start: "bottom bottom",
         end:"+=1500",
        scrub:true,
    },
     backgroundColor:"rgb(220 20 60)",
});

gsap.to('#columna2', {
    scrollTrigger:  {
        trigger:"#inicio",
        
        start: "bottom bottom",
         end:"+=1500",
        scrub:true,
    },
    width:"90vw",
     backgroundColor:"black",
});

gsap.to('#columna3', {
    scrollTrigger:  {
        trigger:"#inicio",
        
        start: "bottom bottom",
         end:"+=1500",
        scrub:true,
    },
    backgroundColor:"rgb(220 20 60)",
});

